//
//  SaddahTests.swift
//  SaddahTests
//
//  Created by lujin mohammed on 23/09/1446 AH.
//

import Testing
@testable import Saddah

struct SaddahTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
