//
//  SaddahApp.swift
//  Saddah
//
//  Created by lujin mohammed on 23/09/1446 AH.
//

import SwiftUI

@main
struct SaddahApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                MainPage()
            }
        }
    }
}
